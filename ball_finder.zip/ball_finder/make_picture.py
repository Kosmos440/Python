import cv2
import numpy as np
import configparser

def make_picture(coords, frames, field, image):
    config = configparser.ConfigParser()
    config.read('Console_Variables.ini')
    X_OFFSET = config.get("Settings", "X_OFFSET")
    Y_OFFSET = config.get("Settings", "Y_OFFSET")
    X_OFFSET = int(X_OFFSET)
    Y_OFFSET = int(Y_OFFSET)
    black = np.zeros((500, 1000,3), dtype='uint8')
    cv2.circle(black, (500, 500), 100, (125, 125, 0), thickness = -1)
    cv2.circle(black, (500, 500), 500, (20, 75, 0), thickness = 1)
    cv2.rectangle(black, (500-143+X_OFFSET, 500-Y_OFFSET), (500+143+X_OFFSET, 500-200-Y_OFFSET), (255, 50, 50), thickness = 1)
    for x,y in coords:
        x = 500+x+X_OFFSET-143
        y = 500-(y+Y_OFFSET)
        cv2.circle(black, (x, y), 20, (100, 0, 100), thickness = -1)
    for frame in frames:
        x, y, w, h = frame
        cv2.rectangle(field, (x, y), (x+w, y+h), (255,0,0), 2)
    collage = cv2.hconcat([cv2.resize(field,(500, 350)), cv2.resize(image,(500, 350))])
    collage = cv2.vconcat([black, collage])
    n=0.75
    return cv2.resize(collage,(0, 0),fx=n,fy=n)
