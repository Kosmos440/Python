import cv2
import numpy as np
dictionary = cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_50)


def line_intersection(x1_1,y1_2,x1_3,y1_4,x2_1,y2_2,x2_3,y2_4):
    if x1_1==x1_3:x1_1+=0.0001
    k1 = (y1_2 - y1_4) / (x1_1 - x1_3)
    b1 = y1_4-k1*x1_3
    if x2_1 == x2_3: x2_1+= 0.0001
    k2 = (y2_2 - y2_4) / (x2_1 - x2_3)
    b2 = y2_4 - k2*x2_3
    x = (b2-b1) / (k1-k2)
    y = k1*x+b1
    return [x, y]

def find_line_points(marker, res):
    if marker == 0:
        pt1 = list(res[0][np.where(res[1] == 3)[0][0]][0][3].astype(np.int16))
        pt2 = list(res[0][np.where(res[1] == 3)[0][0]][0][0].astype(np.int16))
        pt3 = list(res[0][np.where(res[1] == 1)[0][0]][0][1].astype(np.int16))
        pt4 = list(res[0][np.where(res[1] == 1)[0][0]][0][0].astype(np.int16))
    elif marker == 1 or marker == 2:
        pt1 = list(res[0][np.where(res[1] == marker-1)[0][0]][0][marker-1].astype(np.int16))
        pt2 = list(res[0][np.where(res[1] == marker-1)[0][0]][0][marker].astype(np.int16))
        pt3 = list(res[0][np.where(res[1] == marker+1)[0][0]][0][marker].astype(np.int16))
        pt4 = list(res[0][np.where(res[1] == marker+1)[0][0]][0][marker+1].astype(np.int16))
    elif marker == 3:
        pt1 = list(res[0][np.where(res[1] == 0)[0][0]][0][0].astype(np.int16))
        pt2 = list(res[0][np.where(res[1] == 0)[0][0]][0][3].astype(np.int16))
        pt3 = list(res[0][np.where(res[1] == 2)[0][0]][0][2].astype(np.int16))
        pt4 = list(res[0][np.where(res[1] == 2)[0][0]][0][3].astype(np.int16))
    return [pt1, pt2], [pt3, pt4]

def get_lost_point(marker, point):
    if marker==0: return[0, 0]
    if marker==1: return[640, 0]
    if marker==2: return[640, 480]
    if marker==3: return[0, 480]

def get_field(image):
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    res = cv2.aruco.detectMarkers(gray,dictionary)
    coords=[]
    height, width, _ = image.shape
    if res[1] is not None and len(res[1])==4 or len(res[1])==3 and np.sum(res[1])<=6:
        for i in range(4):
            marker=i
            if marker in res[1]:
                index = np.where(res[1] == marker)[0][0]
                pt0 = res[0][index][0][marker].astype(np.int16)
                coords.append(list(pt0))
            else:
                x1_1 = find_line_points(marker, res)[0][0][0]
                y1_2 = find_line_points(marker, res)[0][0][1]
                x1_3 = find_line_points(marker, res)[0][1][0]
                y1_4 = find_line_points(marker, res)[0][1][1]
                x2_1 = find_line_points(marker, res)[1][0][0]
                y2_2 = find_line_points(marker, res)[1][0][1]
                x2_3 = find_line_points(marker, res)[1][1][0]
                y2_4 = find_line_points(marker, res)[1][1][1]
                coords.append(line_intersection(x1_1,y1_2,x1_3,y1_4,x2_1,y2_2,x2_3,y2_4))
        input_pt = np.array(coords)
        output_pt = np.array([[0, 0], [width, 0],[width, height],[0, height]])
        h, _ = cv2.findHomography(input_pt, output_pt)
        res_img = cv2.warpPerspective(image, h, (width, height))
        return (res_img)
    
    return None
