import cv2
import numpy as np
import urx, time
import math3d as m3d
import configparser
robot = urx.Robot('192.168.137.60')
config = configparser.ConfigParser()
config.read('Console_Variables.ini')
X_HOME  = config.get("Home_Position", "X_COORD")
Y_HOME  = config.get("Home_Position", "Y_COORD")
Z_HOME  = config.get("Home_Position", "Y_COORD")
F_ROTATION  = config.get("Home_Position", "F_ROTATION")
S_ROTATION  = config.get("Home_Position", "S_ROTATION")
T_ROTATION  = config.get("Home_Position", "T_ROTATION")


def Home_position():
    robot.movel([X_HOME, Y_HOME, Z_HOME, F_ROTATION, S_ROTATION, T_ROTATION] , 0.3 , 0.15, wait = True)
    time.sleep(1)
    
def robot_control(x,y):
    Home_position()
    x_cord = config.get('Variable', 'x_cord')
    y_cord = config.get('Variable', 'y_cord')
    if x_cord-5 <= x and x_cord+5 >= x and y_cord-5 <= y and y_cord+5 >= y:
        robot.movel([x, y, Z_HOME, 0, 3.14, 0] , 0.3 , 0.15, wait = True)
        time.sleep(1)
        robotiqgrip.gripper_action(250)
        time.sleep(1)
        robot.movel([x, y, 0.02, 0, 3.14, 0] , 0.3 , 0.15, wait = True)
        time.sleep(1)
        robotiqgrip.gripper_action(0)
        time.sleep(1)
        robot.movel([x, y, Z_HOME, 0, 3.14, 0] , 0.3 , 0.15, wait = True)
        time.sleep(1)
        Home_position()
        robotiqgrip.gripper_action(250)
        time.sleep(1)
    config['Variable']['x_cord'] = x
    config['Variable']['y_cord'] = y
    with open('Console_Variables.ini', 'w') as configfile:
        config.write(configfile)
    
