import cv2
import numpy as np
from get_img import get_img
from get_field import get_field
from get_bin import get_bin
from get_coords import get_coords
from get_robot_coords import get_robot_coords
from make_picture import make_picture

while True:
    img = get_img('77.37.184.204')
    field = get_field(img)
    if field is not None:
        mask = get_bin(field)
        coords, frames = get_coords(mask, x_size_mm = 286, y_size_mm = 200)
        robot_coords = get_robot_coords(coords)
        picture = make_picture(coords, frames, field, img)
        cv2.imshow('image',picture)
    if cv2.waitKey(500) == 27:
        break

cv2.destroyAllWindows()
