import cv2
import numpy as np


def get_bin(image):
    hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
    img_bin = cv2.inRange(hsv[:,:,0],0,70)
    kernel = np.ones((5, 5), 'uint8')
    img_bin = cv2.erode(img_bin, kernel, iterations=10)
    img_bin = cv2.dilate(img_bin, kernel, iterations=10)
    return img_bin
